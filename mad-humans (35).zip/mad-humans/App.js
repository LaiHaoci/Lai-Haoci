import React, { useState } from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './Login';
import SignUp from './SignUp'; 
import Home from './Home';
import Quiz from './Quiz';
import Idiom from './Idiom';
import IdiomList from './IdiomList';
import CategoryList from './CategoryList'
import Review from './Review';
import IdiomDetails from './IdiomDetails';
import AgeIdiomList from './AgeIdiomList';
import AnimalIdiomList from './AnimalIdiomList';
import QuizList from './QuizList';
import IdiomQuizList from './IdiomQuizList';
import MeaningQuizList from './MeaningQuizList';
import MQuiz from './MQuiz';
import AssetExample from './components/AssetExample';
import { Card } from 'react-native-paper';

const Stack = createStackNavigator();

function App() {
  console.log("App Executed");

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="SignUp" component={SignUp} />
      <Stack.Screen name="Home" component={Home} />
      <Stack.Screen name="Quiz" component={Quiz} />
      <Stack.Screen name="MQuiz" component={MQuiz} />
      <Stack.Screen name="IdiomList" component={IdiomList} />
      <Stack.Screen name="CategoryList" component={CategoryList} />
      <Stack.Screen name="Review" component={Review} />
      <Stack.Screen name="IdiomDetails" component={IdiomDetails} />
      
      <Stack.Screen name="AgeIdiomList">
        {({ navigation }) => <AgeIdiomList navigation={navigation} idioms={Idiom} />} 
      </Stack.Screen>
      
      <Stack.Screen name="AnimalIdiomList">
      {({ navigation }) => <AnimalIdiomList navigation={navigation} idioms={Idiom} />} 
      </Stack.Screen>

      <Stack.Screen name="QuizList" component={QuizList} />
      <Stack.Screen name="IdiomQuizList" component={IdiomQuizList} />
      <Stack.Screen name="MeaningQuizList" component={MeaningQuizList} />
    </Stack.Navigator>
  );
}

export default () => {
  return (
    <NavigationContainer>
      <App />
    </NavigationContainer>
  );
}