import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './Home';

const questions = [
  {
    question: "What is the meaning of a piece of cake? Choose the most accurate one!",
    options: ['A. Something very delicious', 'B. Something very difficult', 'C. Something very easy', 'D. Something very small'],
    correctAnswer: 'C. Something very easy',
  },
  {
    question: "What is the meaning of break a leg? Choose the most accurate one!",
    options: ['A. Good luck', 'B. Very unlucky', 'C. The best way', 'D. Something not good'],
    correctAnswer: 'A. Good luck',
  },
  {
    question: "What is the meaning of act your age? Choose the most accurate one!",
    options: ['A. Do things that are appropriate for your age group.', 'B. Act older than your actual age.', 'C. Imitate the behavior of older individuals.', 'D. Stop being childish, behave maturely!'],
    correctAnswer: 'D. Stop being childish, behave maturely!',
  },
  {
    question: "What is the meaning of asleep at the switch? Choose the most accurate one!",
    options: ['A. Not to be alert on oppurtunity.', 'B. A person who be alert at anytime.', 'C. Feeling tired after long time working.', 'D. Someone feel boring and asleep'],
    correctAnswer: 'A. Not to be alert on oppurtunity.',
  },
   {
    question: "What is the meaning of under the weather? Choose the most accurate one!",
    options: ['A. Not feeling well.', 'B. Cannot bear the weather.', 'C. Feeling tired and asleep.', 'D. Want to go to bath.'],
    correctAnswer: 'A. Not feeling well.',
  },
];

function QuizScreen({ navigation }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);

  const handleAnswer = (selectedOption) => {
    if (selectedOption === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };

  const handleReturn = () => {
    navigation.navigate('Home');
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
  };


return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF' }}>
      {showScore ? (
        <View>
          <Text style={{ fontSize: 24, marginBottom: 10 }}>
            Your Score: {score} out of {questions.length}
          </Text>
          <View style={{ marginVertical: 10 }}>
            <Button
              title="Restart Quiz"
              onPress={handleRestart} 
            />
          </View>
          <View style={{ marginVertical: 10 }}>
            <Button title="Return to Home" onPress={handleReturn} />
          </View>
        </View>
      ) : (
        <View>
          <Text style={{ fontSize: 24, marginBottom: 10 }}>
            Question {currentQuestion + 1}:
          </Text>
          <Text style={{ fontSize: 20, marginBottom: 20 }}>
            {questions[currentQuestion].question}
          </Text>
          {questions[currentQuestion].options.map((option) => (
            <View key={option} style={{ marginVertical: 5 }}>
              <Button
                title={option}
                onPress={() => handleAnswer(option)}
              />
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

const Stack = createStackNavigator();

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Quiz" component={QuizScreen} />
    </Stack.Navigator>
  );
}
