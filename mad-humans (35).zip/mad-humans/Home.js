import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Home Screen</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Idiom"
          onPress={() => navigation.navigate('IdiomList')}
        />
      </View>      
      <View style={styles.buttonContainer}>
        <Button
          title="Category"
          onPress={() => navigation.navigate('CategoryList')}
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Quiz"
          onPress={() => navigation.navigate('QuizList')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    marginTop: 10,
    width: '50%',
  },
});

export default HomeScreen;

