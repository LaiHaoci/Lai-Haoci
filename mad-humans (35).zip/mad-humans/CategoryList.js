import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

function CategoryList({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>CategoryList</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Age"
          onPress={() => navigation.navigate('AgeIdiomList')}
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Animal"
          onPress={() => navigation.navigate('AnimalIdiomList')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    marginTop: 10,
    width: '50%',
    color: '#00FFFF'
  },
});

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="CategoryList" component={CategoryList} />
    </Stack.Navigator>
  );
}

