import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Home screen component
function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text>Welcome to the Homepage!</Text>
    </View>
  );
}

// Sign up screen component
function SignUpScreen() {
  return (
    <View style={styles.container}>
      <Text>Sign Up Screen</Text>
    </View>
  );
}

const Stack = createStackNavigator();

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const navigation = useNavigation();

  const handleSignUp = () => {
    navigation.navigate('SignUp');
  };

 const handleLogin = () => {
  if (email === 'haoci@gmail.com' && password === '1234567') {
    navigation.navigate('Home');
  } else {
    Alert.alert('Error', 'Invalid username or password'); 
  }
};

  return (
      <Stack.Navigator>
        <Stack.Screen name="Login">
          {() => (
            <View style={styles.container}>
              <TextInput
                style={styles.input}
                placeholder="Email"
                onChangeText={(text) => setEmail(text)}
                value={email}
              />
              <TextInput
                style={styles.input}
                placeholder="Password"
                secureTextEntry
                onChangeText={(text) => setPassword(text)}
                value={password}
              />
              <View style={styles.buttonContainer}>
                <Button title="Login" onPress={handleLogin} />
                <Button title="Sign Up" onPress={handleSignUp} />
              </View>
            </View>
          )}
        </Stack.Screen>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />
      </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFFFFF'
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 8,
  },
});
