import React from 'react';
import { View, Text, TouchableOpacity, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createStackNavigator } from '@react-navigation/stack';
import Review from './Review';
import idioms from './Idiom';
import IdiomDetails from './IdiomDetails';

const Stack = createStackNavigator();

const AgeIdiomList = ({ navigation, idioms }) => {
  const [selectedIdioms, setSelectedIdioms] = React.useState([]);

 const toggleIdiomSelection = (id) => {
  setSelectedIdioms((prevSelectedIdioms) =>
    prevSelectedIdioms.includes(id)
      ? prevSelectedIdioms.filter((selectedId) => selectedId !== id)
      : [...prevSelectedIdioms, id]
  );
};


  const handleReviewButtonPress = () => {
    navigation.navigate('Review', { selectedIdioms }); // Pass the selected idioms to the Review screen
  };

  const renderIdiom = ({ item }) => (
  <TouchableOpacity
    style={{ borderWidth: 1, borderColor: 'gray', borderRadius: 10, marginBottom: 16, padding: 16 }}
    onPress={() => navigation.navigate('IdiomDetails', { idiom: item })}
  >
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingLeft: 4 }}>
      <TouchableOpacity onPress={() => toggleIdiomSelection(item.id)}>
        <Ionicons
          name={selectedIdioms.includes(item.id) ? 'heart' : 'heart-outline'}
          size={20}
          color={selectedIdioms.includes(item.id) ? 'red' : 'black'}
          style={{ marginRight: 6 }}
        />
      </TouchableOpacity>
      <View style={{ marginLeft: 6 }}>
        <Text style={{ fontSize: 20, fontWeight: 'bold' }}>{item.phrase}</Text>
        <Text style={{ fontSize: 14 }}>{item.meaning}</Text>
        <Text style={{ fontSize: 14, fontStyle: 'italic' }}>{item.example}</Text>
      </View>
    </View>
  </TouchableOpacity>
);


  // Display the idioms for age category
  const ageIdiomsFiltered = idioms.filter((idiom) => idiom.category === 'Age');

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#FFFFFF' }}>
      <FlatList
        data={ageIdiomsFiltered}
        renderItem={renderIdiom}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingBottom: 16 }}
      />
      <TouchableOpacity
        style={{ backgroundColor: 'lightblue', padding: 16, borderRadius: 10 }}
        onPress={handleReviewButtonPress} 
        disabled={selectedIdioms.length === 0}
      >
        <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 18 }}>Review</Text>
      </TouchableOpacity>
    </View>
  );
};

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="AgeIdiomList">
        {({ navigation }) => <AgeIdiomList navigation={navigation} idioms={idioms} />} 
      </Stack.Screen>
      <Stack.Screen name="Review" component={Review} />
      <Stack.Screen name="IdiomDetails" component={IdiomDetails} />
    </Stack.Navigator>
  );
}
