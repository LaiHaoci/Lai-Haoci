import { Asset } from 'expo-asset';

const idioms = [
  {
    id: 1,
    phrase: "A piece of cake",
    meaning: "Something very easy",
    example: "The exam was a piece of cake.",
    image: Asset.fromModule(require('./assets/cake.jpg')).uri,
    audio: Asset.fromModule(require('./assets/A_piece_of_cake_Some.mp3')).uri,
    video: Asset.fromModule(require('./assets/Video10100.mp4')).uri
  },
  
  {
    id: 2,
    phrase: "Break a leg",
    meaning: "Good luck",
    example: "Break a leg on your performance tonight.",
    image: Asset.fromModule(require('./assets/leg.webp')).uri,
    audio: Asset.fromModule(require('./assets/Break_a_leg.mp3')).uri,
    video: Asset.fromModule(require('./assets/Video212.mp4')).uri
  }, 
  
  {
    id: 3,
    phrase: "Act your age",
    meaning: "Stop being childish, behave maturely!",
    example: "Boys, behave appropriately and act your age!",
    category: "Age",
    image: Asset.fromModule(require('./assets/age.webp')).uri,
    audio: Asset.fromModule(require('./assets/Act_your_age.mp3')).uri,
    video: Asset.fromModule(require('./assets/Video333.mp4')).uri
  },

  {
    id: 4,
    phrase: "It's raining cats and dogs",
    meaning: "Raining unusually or unbelievably hard",
    example: "No chance they'll play at the park, it's raining cats and dogs!",
    category: "Animal",
    image: Asset.fromModule(require('./assets/cute.jpg')).uri,
    audio: Asset.fromModule(require('./assets/It_raining.mp3')).uri,
    video: Asset.fromModule(require('./assets/Video14.mp4')).uri
  },

  {
    id: 5,
    phrase: "Like water off a duck's back",
    meaning: "To be unaffected or untroubled by criticism or negative situations.",
    example: "Despite the criticism, she remained calm like water off a duck's back.",
    category: "Animal",
    image: Asset.fromModule(require('./assets/duck.jpg')).uri,
    audio: Asset.fromModule(require('./assets/Like_water.mp3')).uri,
    video: Asset.fromModule(require('./assets/Video15.mp4')).uri
  }
  
];

export default idioms;
