import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

function MeaningQuizList({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Meaning Quiz List</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Meaning Quiz"
          onPress={() => navigation.navigate('MQuiz')}
        />
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    marginTop: 10,
    width: '50%',
  },
});

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MeaningQuizList" component={MeaningQuizList} />
    </Stack.Navigator>
  );
}

