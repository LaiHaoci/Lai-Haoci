import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './Home';

const questions = [
  {
    question: "(it's) raining cats and dogs. It is raining cats and dogs, so",
    options: ['A. watch out for falling animals', 'B. make sure you take an umbrella', 'C. keep your pets inside'],
    correctAnswer: 'B. make sure you take an umbrella',
  },
  {
    question: "(like) water off a duck's back. Many people claim that insults or negative comments are like water off a duck's back, but in reality, many of them are",
    options: ['A. pleased by such things', 'B. upset by such things', 'C. unaffected by such things'],
    correctAnswer: 'B. upset by such things',
  },
  {
    question: "(your) bread and butter. This job is my bread and butter, so ",
    options: ['A. I do not really need it', 'B. I do not get paid for it', 'C. I cannot afford to lose it'],
    correctAnswer: 'C. I cannot afford to lose it',
  },
  {
    question: "feel the pinch. Most people have been feeling the pinch because of ",
    options: ['A.  falling prices', 'B.  steady prices', 'C. rising prices'],
    correctAnswer: 'C. rising prices',
  },
  {
    question: "a drop in the ocean. It means how many that a person needed for that ",
    options: ['A.  a small part of what is needed', 'B. a huge part of what is needed', 'C. all that are needed'],
    correctAnswer: 'A.  a small part of what is needed',
  },
];

function QuizScreen({ navigation }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);

  const handleAnswer = (selectedOption) => {
    if (selectedOption === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };

  const handleReturn = () => {
    navigation.navigate('Home');
  };

  const handleRestart = () => {
    // Reset state values to restart the quiz from the first question
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF' }}>
      {showScore ? (
        <View>
          <Text style={{ fontSize: 24, marginBottom: 10 }}>
            Your Score: {score} out of {questions.length}
          </Text>
          <View style={{ marginVertical: 10 }}>
            <Button
              title="Restart Quiz"// Call the handleRestart function on button press
              onPress={handleRestart}
            />
          </View>
          <View style={{ marginVertical: 10 }}>
            <Button title="Return to Home" onPress={handleReturn} />
          </View>
        </View>
      ) : (
        <View>
          <Text style={{ fontSize: 24, marginBottom: 10 }}>
            Question {currentQuestion + 1}:
          </Text>
          <Text style={{ fontSize: 20, marginBottom: 20 }}>
            {questions[currentQuestion].question}
          </Text>
          {questions[currentQuestion].options.map((option) => (
            <View key={option} style={{ marginVertical: 5 }}>
              <Button
                title={option}
                onPress={() => handleAnswer(option)}
              />
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

const Stack = createStackNavigator();

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Quiz" component={QuizScreen} />
    </Stack.Navigator>
  );
}