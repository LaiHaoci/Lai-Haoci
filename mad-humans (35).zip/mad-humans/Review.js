import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRoute } from '@react-navigation/native';
import idioms from './Idiom';

const Review = () => {
  const route = useRoute();
  const selectedIdioms = route.params?.selectedIdioms || [];

  const selectedIdiomsData = idioms.filter((item) => selectedIdioms.includes(item.id));
  
  const renderItem = ({ item }) => {
    return (
      <View style={styles.idiomContainer}>
        <Text style={styles.heart}>
          <Ionicons name="heart" size={20} color="red" />
        </Text>
        <View style={styles.idiomTextContainer}>
          <Text style={styles.idiomPhrase}>{item.phrase}</Text>
          <Text style={styles.idiomMeaning}>{item.meaning}</Text>
          <Text style={styles.idiomExample}>{item.example}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#FFFFFF' }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Review Idioms:</Text>
      <FlatList
        data={selectedIdiomsData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  idiomContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  heart: {
    marginRight: 10,
  },
  idiomTextContainer: {
    flex: 1,
  },
  idiomPhrase: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  idiomMeaning: {
    fontSize: 14,
  },
  idiomExample: {
    fontSize: 14,
    fontStyle: 'italic',
  },
});

export default Review;
