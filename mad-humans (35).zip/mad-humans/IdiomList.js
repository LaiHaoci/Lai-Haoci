import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import Review from './Review';
import idioms from './Idiom';
import IdiomDetails from './IdiomDetails';

const Stack = createStackNavigator();

const IdiomList = ({ navigation }) => {
  const [selectedIdioms, setSelectedIdioms] = useState([]);

  const toggleIdiomSelection = (id) => {
    setSelectedIdioms((prevSelectedIdioms) =>
      prevSelectedIdioms.includes(id)
        ? prevSelectedIdioms.filter((selectedId) => selectedId !== id)
        : [...prevSelectedIdioms, id]
    );
  };

  const isIdiomSelected = (id) => selectedIdioms.includes(id);

  const renderIdiom = ({ item }) => (
    <TouchableOpacity
      style={styles.idiomContainer}
      onPress={() => navigation.navigate('IdiomDetails', { idiom: item })}
    >
      <View style={styles.idiomContent}>
        <TouchableOpacity onPress={() => toggleIdiomSelection(item.id)}>
          <Ionicons
            name={isIdiomSelected(item.id) ? 'heart' : 'heart-outline'}
            size={20}
            color={isIdiomSelected(item.id) ? 'red' : 'black'}
            style={styles.heartIcon}
          />
        </TouchableOpacity>
        <View style={styles.idiomText}>
          <Text style={styles.phraseText}>{item.phrase}</Text>
          <Text style={styles.meaningText}>{item.meaning}</Text>
          <Text style={styles.exampleText}>{item.example}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const handleReviewButtonPress = () => {
    navigation.navigate('Review', { selectedIdioms });
  };

const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 20,
      backgroundColor: '#FFFFFF',
    },
    idiomContainer: {
      borderWidth: 1,
      borderColor: 'gray',
      borderRadius: 10,
      marginBottom: 16,
      padding: 12, 
    },
    idiomContent: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingLeft: 4,
    },
    heartIcon: {
      marginRight: 6,
    },
    idiomText: {
      marginLeft: 6,
    },
    phraseText: {
      fontSize: 16, 
      fontWeight: 'bold',
    },
    meaningText: {
      fontSize: 12, 
    },
    exampleText: {
      fontSize: 12, 
      fontStyle: 'italic',
    },
    reviewButton: {
      backgroundColor: '#007BFF',
      paddingVertical: 8, 
      paddingHorizontal: 12, 
      borderRadius: 8,
      alignItems: 'center',
      marginTop: 10,
    },
    reviewButtonText: {
      color: '#FFF',
      fontSize: 14, 
      fontWeight: 'bold',
    },
  });

  return (
    <View style={styles.container}>
      <FlatList
        data={idioms}
        renderItem={renderIdiom}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingBottom: 16 }}
      />
      <TouchableOpacity style={styles.reviewButton} onPress={handleReviewButtonPress}>
        <Text style={styles.reviewButtonText}>Review</Text>
      </TouchableOpacity>
    </View>
  );
};

export default function App() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="IdiomList" component={IdiomList} />
      <Stack.Screen name="Review" component={Review} />
      <Stack.Screen name="IdiomDetails" component={IdiomDetails} />
    </Stack.Navigator>
  );
}
