import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Image, TouchableOpacity, Button, ScrollView, StyleSheet } from 'react-native';
import { Video, Audio } from 'expo-av';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import Review from './Review';

const IdiomDetails = ({ route }) => {
  const { idiom } = route.params;
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioPlayer, setAudioPlayer] = useState(null);
  const [showVideo, setShowVideo] = useState(false); // State to control video display
  const videoRef = useRef(null); // Ref for the Video component
  const navigation = useNavigation();

  useEffect(() => {
    setupAudioPlayer();
    return () => {
      if (audioPlayer) {
        audioPlayer.unloadAsync();
      }
    };
  }, []);

  const setupAudioPlayer = async () => {
    try {
      const player = new Audio.Sound();
      await player.loadAsync({ uri: idiom.audio });
      player.setIsLoopingAsync(true);
      setAudioPlayer(player);
    } catch (error) {
      console.error('Error setting up audio player:', error);
    }
  };

  const toggleAudioPlayback = async () => {
    try {
      if (audioPlayer) {
        if (isPlaying) {
          await audioPlayer.pauseAsync();
        } else {
          await audioPlayer.playAsync();
        }
        setIsPlaying(!isPlaying);
      }
    } catch (error) {
      console.error('Error toggling audio playback:', error);
    }
  };

  const handleReviewPress = () => {
    navigation.navigate('Review', { selectedIdiom: idiom });
  };

  const handleDisplayVideo = () => {
    setShowVideo(true);
  };

   const handleReplayVideo = async () => {
    if (videoRef.current) {
      try {
        await videoRef.current.setPositionAsync(0);
        await videoRef.current.playAsync();
      } catch (error) {
        console.error('Error replaying video:', error);
      }
    }
  };

  console.log('idiom.audio:', idiom.audio);
  console.log('audioPlayer:', audioPlayer);
  console.log('isPlaying:', isPlaying);

return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 20, backgroundColor: '#FFFFFF' }}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>{idiom.phrase}</Text>
      </TouchableOpacity>
      <Text style={{ fontSize: 14, marginBottom: 10 }}>Meaning: {idiom.meaning}</Text>
      <Text style={{ fontSize: 14 }}>Example: {idiom.example}</Text>
      {idiom.image && (
        <Image source={{ uri: idiom.image }} style={{ width: 200, height: 200, marginBottom: 10, alignItems: 'center' }} />
      )}

      {showVideo && idiom.video && (
        <View>
          <Video
            ref={videoRef}
            source={{ uri: idiom.video }}
            style={{ width: 300, height: 200, marginBottom: 10 }}
            useNativeControls
            resizeMode="contain"
          />
        </View>
      )}

      {idiom.audio && (
        <TouchableOpacity
          onPress={toggleAudioPlayback}
          style={{ position: 'absolute', top: 20, right: 60, alignSelf: 'flex-end' }}
        >
          <Ionicons name={isPlaying ? 'volume-high' : 'volume-mute'} size={30} color="black" />
        </TouchableOpacity>
      )}

      {idiom.video && (
        <View>
          <Button title="Display" onPress={handleDisplayVideo} />
          {showVideo && (
            <Button title="Replay" onPress={handleReplayVideo} />
          )}
        </View>
      )}

     <TouchableOpacity
  onPress={handleReviewPress}
  style={{ position: 'absolute', top: 20, right: 20, alignSelf: 'flex-end' }}
>
  <Ionicons name="heart" size={30} color="red" />
</TouchableOpacity>
    </ScrollView>
  );
};

export default IdiomDetails;